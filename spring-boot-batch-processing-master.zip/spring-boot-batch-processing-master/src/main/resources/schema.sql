DROP TABLE animes IF EXISTS;
CREATE TABLE animes  (
    id VARCHAR(10),
    title VARCHAR(400),
    description VARCHAR(2000)
);